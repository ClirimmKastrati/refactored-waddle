﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;

namespace Brute_Force_Attack
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void cmbTeknika_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (cmbTeknika.SelectedItem.ToString() == "Ciphertext only")
            {
                txtPlaintext.Hide();
                txtKey.Hide();
                lblKey.Hide();
                lblPlaintext.Hide();
                btnEncrypt.Hide();
                pnlFrequency.Hide();
            }
            else if (cmbTeknika.SelectedItem.ToString() == "Known plaintext")
            {
                txtPlaintext.Show();
                txtKey.Show();
                lblKey.Show();
                lblPlaintext.Show();
                btnEncrypt.Show();
                pnlFrequency.Hide();
            }
            else if (cmbTeknika.SelectedItem.ToString() == "Frequency analysis")
            {
                txtPlaintext.Show();
                txtKey.Hide();
                lblKey.Hide();
                lblPlaintext.Show();
                btnEncrypt.Hide();
                pnlFrequency.Show();
            }
            }

        private void button3_Click(object sender, EventArgs e)
        {
            string plaintext = txtPlaintext.Text;
            string key = txtKey.Text;
            string ciphertext = "";
            int keyy = int.Parse(key);

            for (int i = 0; i < plaintext.Length; i++)
            {
                ciphertext += (char)(plaintext[i] + keyy);
            }
            txtCiphertext.Text = ciphertext;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            if (cmbTeknika.SelectedItem.ToString() == "Ciphertext only")
            {
                string ciphertext = txtCiphertext.Text;

                int c = 0;
                string a = "";
                string b = "";
                while (c < 26)
                {
                    string plaintext = "";
                    for (int i = 0; i < ciphertext.Length; i++)
                    {
                        plaintext += (char)(ciphertext[i] - c);
                        a = plaintext;
                        b = "Key " + c + " : " + a;

                    }
                    MessageBox.Show(b, "Rezultati");
                    c++;
                }

            }
            else if (cmbTeknika.SelectedItem.ToString() == "Frequency analysis")
            {
                string ciphertext = txtCiphertext.Text;
                int a = 0, b = 0, c = 0, d = 0, ee = 0, f = 0, g = 0, h = 0, ii = 0, j = 0, k = 0, l = 0, m = 0, n = 0, o = 0, p = 0, q = 0, r = 0,
                    s = 0, t = 0, u = 0, v = 0, x = 0, w = 0, y = 0, z = 0;

                for (int i = 0; i < ciphertext.Length; i++)
                {
                    if (ciphertext[i] == 'a') { a++; }
                    else if (ciphertext[i] == 'b') { b++; }
                    else if (ciphertext[i] == 'c') { c++; }
                    else if (ciphertext[i] == 'd') { d++; }
                    else if (ciphertext[i] == 'e') { ee++; }
                    else if (ciphertext[i] == 'f') { f++; }
                    else if (ciphertext[i] == 'g') { g++; }
                    else if (ciphertext[i] == 'h') { h++; }
                    else if (ciphertext[i] == 'i') { ii++; }
                    else if (ciphertext[i] == 'j') { j++; }
                    else if (ciphertext[i] == 'k') { k++; }
                    else if (ciphertext[i] == 'l') { l++; }
                    else if (ciphertext[i] == 'm') { m++; }
                    else if (ciphertext[i] == 'n') { n++; }
                    else if (ciphertext[i] == 'o') { o++; }
                    else if (ciphertext[i] == 'p') { p++; }
                    else if (ciphertext[i] == 'q') { q++; }
                    else if (ciphertext[i] == 'r') { r++; }
                    else if (ciphertext[i] == 's') { s++; }
                    else if (ciphertext[i] == 't') { t++; }
                    else if (ciphertext[i] == 'u') { u++; }
                    else if (ciphertext[i] == 'v') { v++; }
                    else if (ciphertext[i] == 'w') { w++; }
                    else if (ciphertext[i] == 'x') { x++; }
                    else if (ciphertext[i] == 'y') { y++; }
                    else if (ciphertext[i] == 'z') { z++; }

                }
                MessageBox.Show("\ta : " + a.ToString() + "\r\n\t" + "b : " + b.ToString() + "\r\n\t" + "c : " + c.ToString()
                                    + "\r\n\t" + "d : " + d.ToString() + "\r\n\t" + "e : " + ee.ToString() + "\r\n\t" + "f : " + f.ToString()
                                    + "\r\n\t" + "g : " + g.ToString() + "\r\n\t" + "h : " + h.ToString() + "\r\n\t" + "i : " + ii.ToString()
                                    + "\r\n\t" + "j : " + j.ToString() + "\r\n\t" + "k : " + k.ToString() + "\r\n\t" + "l : " + l.ToString()
                                    + "\r\n\t" + "m : " + m.ToString() + "\r\n\t" + "n : " + n.ToString() + "\r\n\t" + "o : " + o.ToString()
                                    + "\r\n\t" + "p : " + p.ToString() + "\r\n\t" + "q : " + q.ToString() + "\r\n\t" + "r : " + r.ToString()
                                    + "\r\n\t" + "s : " + s.ToString() + "\r\n\t" + "t : " + t.ToString() + "\r\n\t" + "u : " + u.ToString()
                                    + "\r\n\t" + "v : " + v.ToString() + "\r\n\t" + "w : " + w.ToString() + "\r\n\t" + "x : " + x.ToString()
                                    + "\r\n\t" + "y : " + y.ToString() + "\r\n\t" + "z : " + z.ToString(), "Frequences of ciphertext");

                int [] vlerat = { a, b, c, d, ee, f, g, h, ii, j, k, l, m, n, o, p, q,
                                 r, s, t, u, v, w, x, y, z };
                int max = vlerat.Max();
                int min = vlerat.Min();
                
                if (a == max) {      string first = txtCiphertext.Text.Replace('a', 'e');txtCiphertext.Text = first; }
                else if (b == max) { string first = txtCiphertext.Text.Replace('b', 'e'); txtCiphertext.Text = first; }
                else if (c == max) { string first = txtCiphertext.Text.Replace('c', 'e'); txtCiphertext.Text = first; }
                else if (d == max) { string first = txtCiphertext.Text.Replace('d', 'e'); txtCiphertext.Text = first; }
                else if (ee == max) {string first = txtCiphertext.Text.Replace('e', 'e'); txtCiphertext.Text = first; }
                else if (f == max) { string first = txtCiphertext.Text.Replace('f', 'e'); txtCiphertext.Text = first; }
                else if (g == max) { string first = txtCiphertext.Text.Replace('g', 'e'); txtCiphertext.Text = first; }
                else if (h == max) { string first = txtCiphertext.Text.Replace('h', 'e'); txtCiphertext.Text = first; }
                else if (ii == max) {string first = txtCiphertext.Text.Replace('i', 'e'); txtCiphertext.Text = first; }
                else if (j == max) { string first = txtCiphertext.Text.Replace('j', 'e'); txtCiphertext.Text = first; }
                else if (k == max) { string first = txtCiphertext.Text.Replace('k', 'e'); txtCiphertext.Text = first; }
                else if (l == max) { string first = txtCiphertext.Text.Replace('l', 'e'); txtCiphertext.Text = first; }
                else if (m == max) { string first = txtCiphertext.Text.Replace('m', 'e'); txtCiphertext.Text = first; }
                else if (n == max) { string first = txtCiphertext.Text.Replace('n', 'e'); txtCiphertext.Text = first; }
                else if (o == max) { string first = txtCiphertext.Text.Replace('o', 'e'); txtCiphertext.Text = first; }
                else if (p == max) { string first = txtCiphertext.Text.Replace('p', 'e'); txtCiphertext.Text = first; }
                else if (q == max) { string first = txtCiphertext.Text.Replace('q', 'e'); txtCiphertext.Text = first; }
                else if (r == max) { string first = txtCiphertext.Text.Replace('r', 'e'); txtCiphertext.Text = first; }
                else if (s == max) { string first = txtCiphertext.Text.Replace('s', 'e'); txtCiphertext.Text = first; }
                else if (t == max) { string first = txtCiphertext.Text.Replace('t', 'e'); txtCiphertext.Text = first; }
                else if (u == max) { string first = txtCiphertext.Text.Replace('u', 'e'); txtCiphertext.Text = first; }
                else if (v == max) { string first = txtCiphertext.Text.Replace('v', 'e'); txtCiphertext.Text = first; }
                else if (w == max) { string first = txtCiphertext.Text.Replace('w', 'e'); txtCiphertext.Text = first; }
                else if (x == max) { string first = txtCiphertext.Text.Replace('x', 'e'); txtCiphertext.Text = first; }
                else if (y == max) { string first = txtCiphertext.Text.Replace('y', 'e'); txtCiphertext.Text = first; }
                else if (z == max) { string first = txtCiphertext.Text.Replace('z', 'e'); txtCiphertext.Text = first; }

                if (a == min) {      string first = txtCiphertext.Text.Replace('a', 'z'); txtCiphertext.Text = first; }
                else if (b == min) { string first = txtCiphertext.Text.Replace('b', 'z'); txtCiphertext.Text = first; }
                else if (c == min) { string first = txtCiphertext.Text.Replace('c', 'z'); txtCiphertext.Text = first; }
                else if (d == min) { string first = txtCiphertext.Text.Replace('d', 'z'); txtCiphertext.Text = first; }
                else if (ee == min) {string first = txtCiphertext.Text.Replace('e', 'z'); txtCiphertext.Text = first; }
                else if (f == min) { string first = txtCiphertext.Text.Replace('f', 'z'); txtCiphertext.Text = first; }
                else if (g == min) { string first = txtCiphertext.Text.Replace('g', 'z'); txtCiphertext.Text = first; }
                else if (h == min) { string first = txtCiphertext.Text.Replace('h', 'z'); txtCiphertext.Text = first; }
                else if (ii == min) {string first = txtCiphertext.Text.Replace('i', 'z'); txtCiphertext.Text = first; }
                else if (j == min) { string first = txtCiphertext.Text.Replace('j', 'z'); txtCiphertext.Text = first; }
                else if (k == min) { string first = txtCiphertext.Text.Replace('k', 'z'); txtCiphertext.Text = first; }
                else if (l == min) { string first = txtCiphertext.Text.Replace('l', 'z'); txtCiphertext.Text = first; }
                else if (m == min) { string first = txtCiphertext.Text.Replace('m', 'z'); txtCiphertext.Text = first; }
                else if (n == min) { string first = txtCiphertext.Text.Replace('n', 'z'); txtCiphertext.Text = first; }
                else if (o == min) { string first = txtCiphertext.Text.Replace('o', 'z'); txtCiphertext.Text = first; }
                else if (p == min) { string first = txtCiphertext.Text.Replace('p', 'z'); txtCiphertext.Text = first; }
                else if (q == min) { string first = txtCiphertext.Text.Replace('q', 'z'); txtCiphertext.Text = first; }
                else if (r == min) { string first = txtCiphertext.Text.Replace('r', 'z'); txtCiphertext.Text = first; }
                else if (s == min) { string first = txtCiphertext.Text.Replace('s', 'z'); txtCiphertext.Text = first; }
                else if (t == min) { string first = txtCiphertext.Text.Replace('t', 'z'); txtCiphertext.Text = first; }
                else if (u == min) { string first = txtCiphertext.Text.Replace('u', 'z'); txtCiphertext.Text = first; }
                else if (v == min) { string first = txtCiphertext.Text.Replace('v', 'z'); txtCiphertext.Text = first; }
                else if (w == min) { string first = txtCiphertext.Text.Replace('w', 'z'); txtCiphertext.Text = first; }
                else if (x == min) { string first = txtCiphertext.Text.Replace('x', 'z'); txtCiphertext.Text = first; }
                else if (y == min) { string first = txtCiphertext.Text.Replace('y', 'z'); txtCiphertext.Text = first; }
                else if (z == min) { string first = txtCiphertext.Text.Replace('z', 'z'); txtCiphertext.Text = first; }

                txtPlaintext.Text = txtCiphertext.Text;
                txtCiphertext.Text = ciphertext;
            }
        }

        private void txtPlaintext_TextChanged(object sender, EventArgs e)
        {
            if (cmbTeknika.SelectedItem.ToString() == "Ciphertext only")
            {
                txtPlaintext.PasswordChar = '*';
                txtKey.PasswordChar = '*';
            }
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
